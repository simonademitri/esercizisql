create schema toysgroup;
-- creazione tavolo prodotto
create table prodotto(
id_prodotto int primary key not null,
nome_prodotto varchar(100),
prezzo_unità int);


-- creazione tavolo regione
create table regione (
id_regione int primary key not null,
nome_regione varchar(100));

-- creazione tavolo vendite
create table vendite(
id_vendite int primary key not null,
categoria varchar(100),
quantità_venduta int,
data_vendita date,
fatturato int,
id_prodotto int,
id_regione int,
foreign key(id_prodotto) references prodotto(id_prodotto),
foreign key(id_regione) references regione(id_regione));

-- popola prodotto
insert into prodotto values
(1,"monopoly",5),
(2,"megatron",8),
(3,"optimus prime",8),
(4,"barbie",6);
-- popola regione
insert into regione values
(1,"puglia"),
(2,"lazio"),
(3,"campania"),
(4,"lombardia");
-- popola vendite
insert into vendite values
(1,"robot",3,'2024-01-17',24,2,3),
(2,"giochi da tavolo",2,'2023-01-17',10,1,2),
(3,"bambole",1,'2024-01-18',6,4,1),
(4,"robot",3,'2022-01-19',24,3,4);

select * from prodotto;
select * from regione;
select * from vendite;
-- verifica pk univoche
show columns from prodotto;
show columns from regione;
show columns from vendite;

-- prodotti venduti e fatturato tot per anno
SELECT 
    p.id_prodotto,
    p.nome_prodotto,
    YEAR(v.data_vendita) AS Anno,
    SUM(v.fatturato) AS Fatturato_Totale
FROM
    prodotto p
INNER JOIN
    vendite v ON p.id_prodotto = v.id_prodotto
GROUP BY
    p.id_prodotto,
    p.nome_prodotto,
    YEAR(v.data_vendita)
ORDER BY
    Anno DESC,
    Fatturato_Totale DESC;
    
    
    -- fatturato tot per regione per anno ordine desc
        SELECT 
    r.nome_regione,
    date(v.data_vendita) AS Anno,
    SUM(v.fatturato) AS Fatturato_Totale
FROM
    Vendite v
INNER JOIN
    Regione r ON v.id_regione = r.id_regione
GROUP BY
    r.nome_regione,
    date(v.data_vendita)
ORDER BY
 Anno desc,
    fatturato_totale desc;
    
    -- categoria articoli maggiormente richiesta
     SELECT 
    categoria,
    sum(quantità_venduta)
FROM 
    vendite
GROUP BY 
    categoria
    
order by  sum(quantità_venduta) desc
limit 1;

-- se ci sono quali sono i prodotti invenduti(io non ho inserito prodotti invenduti infatti la tabelle risultano vuote)
SELECT 
    p.id_prodotto,
    p.nome_prodotto
FROM 
    prodotto p
LEFT JOIN 
    vendite v ON p.id_prodotto = v.id_prodotto
WHERE 
    v.id_vendite IS NULL;
-- secondo modo
SELECT 
    id_prodotto,
    nome_prodotto
FROM 
    prodotto
WHERE 
    id_prodotto NOT IN (SELECT id_prodotto FROM vendite);
    
    -- esponi il prodotto con la data di vendita
    SELECT 
    p.id_prodotto,
    p.nome_prodotto,
    v.data_vendita
FROM 
    prodotto p
INNER JOIN 
    vendite v ON p.id_prodotto = v.id_prodotto;


   



